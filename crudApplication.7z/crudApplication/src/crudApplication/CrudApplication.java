package crudApplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CrudApplication {
	
	static Connection getCon() {
		Connection con = null;
		try {
			/*
			 * Class.forName("oracle.jdbc.driver.OricleDriver");
			 * con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
			 * "system","oracle");
			 */
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/empdetails?useSSL=false", "root", "World!1");
			//System.out.println("Connection established.");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}

	public void insertRecord() {
		try {
			Connection con = getCon();
			String sql = "INSERT INTO bookHub (bookname, bookid, bookprice) VALUES (?, ?, ?)";
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setString(1, "richdad");
			statement.setString(2, "301");
			statement.setInt(3, 999);
			statement.executeUpdate();
			System.out.println("Insert Details-Record created.");
			System.out.println("-------------------");
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void updateRecord() {
		try {
			Connection con = getCon();
			String sql = "UPDATE bookHub set bookname=? where bookid=?";
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setString(1, "Poordad");
			statement.setString(2, "301");
			statement.executeUpdate();
			System.out.println("Update Details-Record updated.");
			System.out.println("-------------------");
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void deleteRecord() {
		try {
			Connection con = getCon();
			String sql = "Delete from bookHub where bookid=?";
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setString(1, "301");
			statement.executeUpdate();
			System.out.println("Delete Details-Record Deleted.");
			System.out.println("-------------------");
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void readRecord() {
		try {
			Connection con = getCon();
			String sql = "SELECT bookname,bookid,bookprice FROM bookHub WHERE bookid = ?";
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setInt(1, 301);
			ResultSet result = statement.executeQuery();
			if (result.next()) {
				String column1 = result.getString("bookname");
				String column2 = result.getString("bookid");
				int column3 = result.getInt("bookprice");
				System.out.println("Book_Name: " + column1);
				System.out.println("Book_Id: " + column2);
				System.out.println("Book_Price: " + column3);
				System.out.println("-------------------");
			}
			else {
				System.out.println("Records doesn't exits");
				System.out.println("-------------------");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void main(String[] args) {
		CrudApplication cru = new CrudApplication();
		cru.insertRecord();
		cru.readRecord();
		cru.updateRecord();
		cru.readRecord();
		cru.deleteRecord(); 
		cru.readRecord();
		 
		
	}

}
